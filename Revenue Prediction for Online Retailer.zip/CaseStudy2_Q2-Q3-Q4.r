install.packages("car")
library(car)
library(readxl)
library(ggplot2)
library(qcc)


df1 <- read_excel("C:/Users/Bartu/Downloads/data.xlsx", sheet = 1)
View(df1)

df1$Gender[df1$Gender == 'Male'] <- 1
df1$Gender[df1$Gender == 'Female'] <- 0
View(df1)
model <- lm(`Revenue($)` ~ Age + Gender + `Pages Visited` + `Time Spent (min)` + `Products Purchased` , data = df1)
lm(model)
summary(model)
anova(model)
residuals <- residuals(model)
hist(residuals)
plot(model, which=5)
cooksd <- cooks.distance(model)
outliers <- which(abs(residuals) < 3 * sd(residuals) | cooksd > 1)

# Plot residuals against fitted values
plot(model, which = 1)  # Residuals vs Fitted values plot

df <- read_excel("C:/Users/Bartu/Downloads/data.xlsx", sheet = 2)
View(df)
df$Gender[df$Gender == 'Male'] <- 1
df$Gender[df$Gender == 'Female'] <- 0

#PART 2-a First we plotted the response against the continious variables.
#Scatter Plots

# Plot response against continuous variables with groups based on the categorical variable
# Check for interactions among variables
plot1 <- ggplot(df, aes(x = Age, y = `Revenue($)`, color = Gender)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Revenue vs. Age by Gender") +
  theme_minimal()

plot2 <- ggplot(df, aes(x = `Pages Visited`, y = `Revenue($)`, color = Gender)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Revenue vs. Pages Visited by Gender") +
  theme_minimal()

plot3 <- ggplot(df, aes(x = `Time Spent (min)`, y = `Revenue($)`, color = Gender)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Revenue vs. Time Spent (min) by Gender") +
  theme_minimal()

plot4 <- ggplot(df, aes(x = `Products Purchased`, y = `Revenue($)`, color = Gender)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Revenue vs. Products Purchased by Gender") +
  theme_minimal()

# Print the plots
print(plot1)
print(plot2)
print(plot3)
print(plot4)

#Interaction Terms
df["PagesVisited_Gender"] <- df$'Pages Visited'*as.numeric(df$Gender)
df["TimeSpent_Gender"] <- df$'Time Spent (min)'*as.numeric(df$Gender)
View(df)

model <- lm(`Revenue($)` ~ Age + Gender + `Pages Visited` + `Time Spent (min)` + `Products Purchased` + PagesVisited_Gender + TimeSpent_Gender, data = df)
lm(model)
summary(model)
anova(model)
# Plot residuals against fitted values
plot(model, which = 1)  # Residuals vs Fitted values plot

residuals <- residuals(model)
par(mfrow = c(2, 2))

plot(model,1)

plot(model,2)

hist(residuals, main = "Histogram of Residuals", xlab = "Residuals", ylab = "Frequency")

qcc(rstandard(model), type = "xbar.one", plot = TRUE)
par(mfrow = c(1, 1))
#PART 2-b First we plotted the scatter Plots of our continious variables
par(mfrow = c(3,3))
plot5 <- ggplot(df, aes(x = Age, y = `Revenue($)`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Revenue vs. Age") +
  theme_minimal()

plot6 <- ggplot(df, aes(x = `Pages Visited`, y = `Revenue($)`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Revenue vs. Pages Visited") +
  theme_minimal()

plot7 <- ggplot(df, aes(x = `Time Spent (min)`, y = `Revenue($)`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Revenue vs. Time Spent (min)") +
  theme_minimal()

plot8 <- ggplot(df, aes(x = `Products Purchased`, y = `Revenue($)`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Revenue vs. Products Purchased") +
  theme_minimal()

plot9 <- ggplot(df, aes(x = PageVisited_Gender, y = `Revenue($)`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Revenue vs. PageVisited_Gender") +
  theme_minimal()

plot10 <- ggplot(df, aes(x = TimeSpent_Gender, y = `Revenue($)`)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "Revenue vs. TimeSpent_Gender") +
  theme_minimal()

# Print the plots
print(plot5)
print(plot6)
print(plot7)
print(plot8)
print(plot9)
print(plot10)

df["Products_Purchased2"] <- df$`Products Purchased`^2

model <- lm(`Revenue($)` ~ Age + Gender + `Pages Visited` + `Time Spent (min)` + `Products Purchased`+ Products_Purchased2 + PagesVisited_Gender + TimeSpent_Gender, data = df)
lm(model)
summary(model)
anova(model)

df["Products_Purchased3"] <- df$`Products Purchased`^3

model <- lm(`Revenue($)` ~ Age + Gender + `Pages Visited` + `Time Spent (min)` + `Products Purchased`+ Products_Purchased2 + Products_Purchased3 + PagesVisited_Gender + TimeSpent_Gender, data = df)
lm(model)
summary(model)
anova(model)
# Plot residuals against fitted values
plot(model, which = 1)  # Residuals vs Fitted values plot

residuals <- residuals(model)
par(mfrow = c(2, 2))
plot(model,1)

plot(model,2)

hist(residuals, main = "Histogram of Residuals", xlab = "Residuals", ylab = "Frequency")

qcc(rstandard(model), type = "xbar.one", plot = TRUE)
par(mfrow = c(1, 1))
#PART 2-c 

model <- lm(`Revenue($)` ~ Age + Gender + `Pages Visited` + `Time Spent (min)` + `Products Purchased`+ Products_Purchased2 + Products_Purchased3 +  TimeSpent_Gender, data = df)
lm(model)
summary(model)
anova(model)

model <- lm(`Revenue($)` ~ Age + Gender + `Time Spent (min)` + `Products Purchased`+ Products_Purchased2 + Products_Purchased3 +  TimeSpent_Gender, data = df)
lm(model)
summary(model)
anova(model)

residuals <- residuals(model)
par(mfrow = c(2, 2))
plot(model,1)

plot(model,2)

hist(residuals, main = "Histogram of Residuals", xlab = "Residuals", ylab = "Frequency")

qcc(rstandard(model), type = "xbar.one", plot = TRUE)
par(mfrow = c(1, 1))

par(mfrow = c(1, 1))
#PART 2-d
model <- lm(`Revenue($)` ~ Age + Gender + `Time Spent (min)` + `Products Purchased`+ Products_Purchased2 + Products_Purchased3 +  TimeSpent_Gender, data = df)
lm(model)
summary(model)
anova(model)
plot(model, which = 1)  # Residuals vs Fitted values plot

#Part 3
df["TimeSpent"] = df$`Time Spent (min)`
df["ProductsPurchased"] = df$`Products Purchased`

f_model <- lm(`Revenue($)` ~ Age + Gender + TimeSpent + ProductsPurchased+ Products_Purchased2 + Products_Purchased3 +  TimeSpent_Gender, data = df)
lm(model)
summary(model)
anova(model)
#Confidence interval
x <- data.frame(Age=25,Gender=as.character(0),TimeSpent = 15 ,ProductsPurchased = 4,Products_Purchased2 =16 , Products_Purchased3=64 , TimeSpent_Gender=0  )
predict(f_model, newdata = x, interval = 'confidence')

#Part 4
#Prediction Interval

y <- data.frame(Age=32,Gender=as.character(1),TimeSpent = 21 ,ProductsPurchased = 2,Products_Purchased2 =4 , Products_Purchased3=8 , TimeSpent_Gender=21  )
predict(f_model, newdata = y, interval = 'prediction')




