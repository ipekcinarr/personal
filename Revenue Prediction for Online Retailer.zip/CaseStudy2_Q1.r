#Question 1


# Load the required library
library(readxl)

# Read the data from the Excel sheet
data <- read_excel("data.xlsx", sheet = "Data")

# Create a contingency table
cont_table <- table(data$Gender, data$`Pages Visited`)

# Perform the chi-squared test
chi_sq_test <- chisq.test(cont_table)

# Print the contingency table
cat("Contingency Table:\n")
print(cont_table)

# Print the chi-squared test results
cat("\nChi-squared Test of Independence:\n")
print(chi_sq_test)

# Determine the conclusion based on the p-value
alpha <- 0.05

if (chi_sq_test$p.value < alpha) {
  cat("\nReject the null hypothesis.")
} else {
  cat("\nFail to reject the null hypothesis.")
}