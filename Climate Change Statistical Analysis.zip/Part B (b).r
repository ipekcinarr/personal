library("xlsx")
library(reshape2)
library(ggplot2)
#Taking Data From Excel
df1 <- read.xlsx("C:/Users/Bartu/Downloads/casestudy1-data.xlsx",sheetIndex = 2)
df2 <- read.xlsx("C:/Users/Bartu/Downloads/casestudy1-data.xlsx",sheetIndex = 3)
View(df1)
View(df2)

CA=df1[df1$Year==2019,]
CB=df2[df2$Year==2019,]
alpha <- 0.05
na <- nrow(CA)
nb <- nrow(CB)

#Petroleum
#We need to check that if our distribution is normal or not
xAbarp=mean(CA[,5])
stdDAp=sd(CA[,5])


qqnorm(CA[,5]); qqline(CA[,5])

hist(CA[,5])

hist(CA[,5], prob = TRUE, main = "Histogram with normal curve")
x1 <- seq(min(CA[,5]), max(CA[,5]), length = 20)
f1 <- dnorm(x1, xAbarp, sd = stdDAp)
lines(x1, f1, col = "red", lwd = 2)

xBbarp=mean(CB[,5])
stdDBp=sd(CB[,5])


qqnorm(CB[,5]); qqline(CB[,5])

hist(CB[,5])

hist(CB[,5], prob = TRUE, main = "Histogram with normal curve")
x2 <- seq(min(CB[,5]), max(CB[,5]), length = 20)
f2 <- dnorm(x2, xBbarp, sd = stdDBp)
lines(x2, f2, col = "blue", lwd = 2)


f_scorep <- qf(alpha/2,nb-1,na-1,lower.tail = FALSE)
LBvarp = (stdDAp^2/stdDBp^2)/f_scorep
UBvarp = (stdDAp^2/stdDBp^2)*f_scorep

t_scorep <- qt(alpha/2, na+nb-2, lower.tail=FALSE)
spp= sqrt((((na-1)*stdDAp^2)+((nb-1)*stdDBp^2))/(na+nb-2))
UBmeanp = xAbarp - xBbarp + t_scorep*spp*sqrt(1/na+1/nb)
LBmeanp = xAbarp - xBbarp - t_scorep*spp*sqrt(1/na+1/nb)


#Natural Gas

xAbarng=mean(CA[,6])
stdDAng=sd(CA[,6])


qqnorm(CA[,6]); qqline(CA[,6])

hist(CA[,6])

hist(CA[,6], prob = TRUE, main = "Histogram with normal curve")
x3 <- seq(min(CA[,6]), max(CA[,6]), length = 20)
f3 <- dnorm(x3, xAbarng, sd = stdDAng)
lines(x3, f3, col = "red", lwd = 2)

xBbarng=mean(CB[,6])
stdDBng=sd(CB[,6])


qqnorm(CB[,6]); qqline(CB[,6])

hist(CB[,6])

hist(CB[,6], prob = TRUE, main = "Histogram with normal curve")
x4 <- seq(min(CB[,6]), max(CB[,6]), length = 20)
f4 <- dnorm(x4, xBbarng, sd = stdDBng)
lines(x4, f4, col = "blue", lwd = 2) 

f_scoreng <- qf(alpha/2,nb-1,na-1,lower.tail = FALSE)
LBvarng = (stdDAng^2/stdDBng^2)/f_scorep
UBvarng = (stdDAng^2/stdDBng^2)*f_scorep

r1 <- (stdDAng^2)/na
r2 <- (stdDBng^2)/nb
vn = floor(((r1+r2)^2 / (((r1^2)/(na+1))+((r2^2)/(nb+1))))-2)

t_scoreng <- qt(alpha/2, vn, lower.tail=FALSE)

UBmeanng = xAbarng - xBbarng + t_scoreng*sqrt(r1+r2)
LBmeanng = xAbarng - xBbarng - t_scoreng*sqrt(r1+r2)

#Coal

xAbarc=mean(CA[,7])
stdDAc=sd(CA[,7])


qqnorm(CA[,7]); qqline(CA[,7])

hist(CA[,7])

hist(CA[,7], prob = TRUE, main = "Histogram with normal curve")
x5 <- seq(min(CA[,7]), max(CA[,7]), length = 20)
f5 <- dnorm(x5, xAbarc, sd = stdDAc)
lines(x5, f5, col = "red", lwd = 2)

xBbarc=mean(CB[,7])
stdDBc=sd(CB[,7])


qqnorm(CB[,7]); qqline(CB[,7])

hist(CB[,7])

hist(CB[,7], prob = TRUE, main = "Histogram with normal curve")
x6 <- seq(min(CB[,7]), max(CB[,7]), length = 20)
f6 <- dnorm(x6, xBbarc, sd = stdDBc)
lines(x6, f6, col = "blue", lwd = 2) 

f_scorec <- qf(alpha/2,nb-1,na-1,lower.tail = FALSE)
LBvarc = (stdDAc^2/stdDBc^2)/f_scorec
UBvarc = (stdDAc^2/stdDBc^2)*f_scorec

t_scorec <- qt(alpha/2, na+nb-2, lower.tail=FALSE)
spc= sqrt((((na-1)*stdDAc^2)+((nb-1)*stdDBc^2))/(na+nb-2))
UBmeanc = xAbarc - xBbarc + t_scorec*spc*sqrt(1/na+1/nb)
LBmeanc = xAbarc - xBbarc - t_scorec*spc*sqrt(1/na+1/nb)

#Total Emission

xAbart=mean(CA[,8])
stdDAt=sd(CA[,8])


qqnorm(CA[,8]); qqline(CA[,8])

hist(CA[,8])

hist(CA[,8], prob = TRUE, main = "Histogram with normal curve")
x7 <- seq(min(CA[,8]), max(CA[,8]), length = 20)
f7 <- dnorm(x7, xAbart, sd = stdDAt)
lines(x7, f7, col = "red", lwd = 2)

xBbart=mean(CB[,8])
stdDBt=sd(CB[,8])


qqnorm(CB[,8]); qqline(CB[,8])

hist(CB[,8])

hist(CB[,8], prob = TRUE, main = "Histogram with normal curve")
x8 <- seq(min(CB[,8]), max(CB[,8]), length = 20)
f8 <- dnorm(x8, xBbart, sd = stdDBt)
lines(x8, f8, col = "blue", lwd = 2) 

f_scoret <- qf(alpha/2,nb-1,na-1,lower.tail = FALSE)
LBvart = (stdDAt^2/stdDBt^2)/f_scoret
UBvart = (stdDAt^2/stdDBt^2)*f_scoret

t_scoret <- qt(alpha/2, na+nb-2, lower.tail=FALSE)
spt= sqrt((((na-1)*stdDAt^2)+((nb-1)*stdDBt^2))/(na+nb-2))
UBmeant = xAbart - xBbart + t_scoret*spt*sqrt(1/na+1/nb)
LBmeant = xAbart - xBbart - t_scoret*spt*sqrt(1/na+1/nb)


