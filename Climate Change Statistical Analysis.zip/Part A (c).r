library("tidyverse")
library("gridExtra")
library("xlsx")
library("qcc")

# Load the Excel file into R
df <- read.xlsx("C:/Users/Bartu/Downloads/casestudy1-data.xlsx", sheetIndex = 1)

EnergyC <- df$Energy_consumption

sd_EnergyC <- sd(EnergyC)

AmountCO2 <- df$CO2_emission

sd_CO2 <- sd(AmountCO2)

EnergyP <- df$Energy_production

sd_EnergyP <- sd(EnergyP)

cov1 <- cov(EnergyC,AmountCO2)

CC1 <- (cov1)/(sd_EnergyC * sd_CO2)

cov2 <- cov(EnergyP,AmountCO2)

CC2 <- (cov2)/(sd_EnergyP * sd_CO2)

print(CC1)
print(CC2)

plot(df$Energy_production,df$CO2_emission,
     pch= 19,
     cex = 0.5,
     col= "#bb0989",
     main= "Scatter Diagram of Relation Between Energy Production and CO2 Emission",
     xlab= "Energy Production unit of Quad BTU",
     ylab= "CO2 Emission unit of Million Metric Tonnes")

plot(df$Energy_consumption,df$CO2_emission,
     pch= 19,
     cex = 0.5,
     col= "#cc0000",
     main= "Scatter Diagram of Relation Between Energy Consumption and CO2 Emission",
     xlab= "Energy Consumption unit of Quad BTU",
     ylab= "CO2 Emission unit of Million Metric Tonnes")
  

