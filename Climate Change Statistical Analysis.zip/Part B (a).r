library("xlsx")
library(reshape2)
library(ggplot2)
#Taking Data From Excel
df <- read.xlsx("C:/Users/Bartu/Downloads/casestudy1-data.xlsx",sheetIndex = 2)
View(df)

Year1=df[df$Year==1995,]
Year2=df[df$Year==2015,]
alpha <- 0.05
na <- nrow(Year1)
nb <- nrow(Year2)


#We need to check that if our distribution is normal or not
x1bar=mean(Year1[,6])
stdD1=sd(Year1[,6])


qqnorm(Year1[,6]); qqline(Year1[,6])

hist(Year1[,6])

hist(Year1[,6], prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(Year1[,6]), max(Year1[,6]), length = 20)
f <- dnorm(x, x1bar, sd = stdD1)
lines(x, f, col = "red", lwd = 2)

x2bar=mean(Year2[,6])
stdD2=sd(Year2[,6])


qqnorm(Year2[,6]); qqline(Year2[,6])

hist(Year2[,6])

hist(Year2[,6], prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(Year2[,6]), max(Year2[,6]), length = 20)
f <- dnorm(x, x2bar, sd = stdD2)
lines(x, f, col = "blue", lwd = 2)

f_scoreng <- qf(alpha/2,nb-1,na-1,lower.tail = FALSE)
LBvarng = (stdD1^2/stdD2^2)/f_scoreng
UBvarng = (stdD1^2/stdD2^2)*f_scoreng

t_scoreng <- qt(alpha, na+nb-2, lower.tail=FALSE)

spng= sqrt((((na-1)*stdD1^2)+((nb-1)*stdD2^2))/(na+nb-2))

UBmeanng = x1bar - x2bar + t_scoreng*spng*sqrt(1/na+1/nb)


#For coal

x3bar=mean(Year1[,7])
stdD3=sd(Year1[,7])


qqnorm(Year1[,7]); qqline(Year1[,7])

hist(Year1[,7])

hist(Year1[,7], prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(Year1[,7]), max(Year1[,7]), length = 20)
f <- dnorm(x, x3bar, sd = stdD3)
lines(x, f, col = "red", lwd = 2)

x4bar=mean(Year2[,7])
stdD4=sd(Year2[,7])


qqnorm(Year2[,7]); qqline(Year2[,7])

hist(Year2[,7])

hist(Year2[,7], prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(Year2[,7]), max(Year2[,7]), length = 20)
f <- dnorm(x, x4bar, sd = stdD4)
lines(x, f, col = "blue", lwd = 2)

f_scorec <- qf(alpha/2,nb-1,na-1,lower.tail = FALSE)
LBvarc = (stdD3^2/stdD4^2)/f_scorec
UBvarc = (stdD3^2/stdD4^2)*f_scorec

t_scorec <- qt(alpha, na+nb-2, lower.tail=FALSE)

spc= sqrt((((na-1)*stdD3^2)+((nb-1)*stdD4^2))/(na+nb-2))

UBmeanc = x3bar - x4bar + t_scorec*spc*sqrt(1/na+1/nb)







