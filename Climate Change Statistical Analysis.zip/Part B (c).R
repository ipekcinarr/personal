# Load the necessary libraries
install.packages("readxl")

library(readxl)
library(ggplot2)

# Read the data from the Excel file
data <- read_excel("casestudy1-data.xlsx", sheet = "Country A")

# Calculate the CO2 emission ratio
data$CO2_emission_ratio <- data$`Total CO_2 emission` / data$`Production (Million tons)`

# Subset the data for 1992 and 2010
data_1992 <- subset(data, Year == 1992)$CO2_emission_ratio
data_2010 <- subset(data, Year == 2010)$CO2_emission_ratio

# Calculate the variances
var_1992 <- var(data_1992)
var_2010 <- var(data_2010)

# Set the significance level
alpha <- 0.05

# Calculate the critical value
f_critical <- qf(alpha/2, length(data_1992)-1, length(data_2010)-1)

# Calculate the confidence interval
ci_lower <- (var_1992 / var_2010) / f_critical
ci_upper <- (var_1992 / var_2010) * f_critical

# Print the confidence interval
cat("Confidence Interval:", ci_lower, "-", ci_upper)


# Calculate the sample sizes for t-test
n1 <- length(data_1992)
n2 <- length(data_2010)

# Calculate the variances per sample size
x1 <- (sd(data_1992)^2) / n1
x2 <- (sd(data_2010)^2) / n2

# Calculate the degrees of freedom
df <- (x1 + x2)^2 / ((x1^2 / (n1 +1)) + (x2^2 / (n2 -+1))) - 2
td <- qt(alpha/2, df, lower.tail = FALSE)

# Calculate the sample means
mean_1992 <- mean(data_1992)
mean_2010 <- mean(data_2010)
lowert <- mean_1992 - mean_2010 - td * sqrt(x1+x2)
uppert <- mean_1992 - mean_2010  + td * sqrt(x1+x2)


# Q-Q plots
qqnorm(data_1992)
qqline(data_1992)
qqnorm(data_2010)
qqline(data_2010)
