library(ggplot2)
library(readxl)

# Read the data from the imported Excel sheet
data <- read_excel("casestudy1-data.xlsx", sheet = "All")

# Part A-b

# Filter the data for the years 1990 and 2019
filtered_data <- filter(data, Year %in% c(1990, 2019))

# Convert character columns to numeric
filtered_data$CO2_emission <- as.numeric(gsub(",", ".", filtered_data$CO2_emission))

# Create a bar plot to compare CO2 emission levels across energy sources
ggplot(filtered_data, aes(x = Energy_type, y = CO2_emission, fill = as.factor(Year))) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(x = "Energy Type", y = "CO2 Emission (Million metric tonnes CO2)",
       title = "Comparison of CO2 Emission Levels across Energy Sources for 1990 and 2019") +
  scale_fill_manual(values = c("1990" = "blue", "2019" = "red")) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  guides(fill = guide_legend(title = "Year"))

# Create boxplots for CO2 emissions by energy source for 1990 and 2019
ggplot(df_1990, aes(x = Energy_type, y = CO2_emission)) +
  geom_boxplot() +
  labs(title = "CO2 Emissions by Energy Source (1990)",
       x = "Energy Source",
       y = "CO2 Emissions")

ggplot(df_2019, aes(x = Energy_type, y = CO2_emission)) +
  geom_boxplot() +
  labs(title = "CO2 Emissions by Energy Source (2019)",
       x = "Energy Source",
       y = "CO2 Emissions")


  