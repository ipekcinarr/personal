library("tidyverse")
library("gridExtra")
library("xlsx")
library("ggplot2")
library("readxl")
df <- read.xlsx("C:/Users/LENOVO/Downloads/66casee.xlsx",sheetIndex = 1)
View(df)
# Filter data for the last 5 years
df_last_5_years <- df %>%
filter(Year >= 2015)
# Exclude USA and China
df_excl_usa_china <- df_last_5_years %>%
filter(Country != "United States" & Country != "China")  
# Calculate total CO2 emissions for each country
df_country_totals <- df_excl_usa_china %>%
group_by(Country) %>%
summarize(total_CO2_emissions = sum(CO2_emission))
# Sort countries by total CO2 emissions
df_country_totals_sorted <- df_country_totals %>%
arrange(desc(total_CO2_emissions))
# Calculate cumulative percentage of total CO2 emissions
df_country_totals_sorted$cumulative_perc <- cumsum(df_country_totals_sorted$total_CO2_emissions) / sum(df_country_totals_sorted$total_CO2_emissions)
# Find countries that produce CO2 emissions for the last 5 years as a cumulative percentage
top_countries <- df_country_totals_sorted %>%
filter(cumulative_perc <= 1)
# Visualize results with a colorful bar plot
ggplot(top_countries, aes(x = reorder(Country, cumulative_perc), y = cumulative_perc, fill = Country)) +
geom_bar(stat = "identity") +
scale_y_continuous(labels = scales::percent_format()) +
ggtitle("Top Countries by CO2 Emissions as a Cumulative Percentage for Last 5 Years") +
xlab("Country") +
ylab("Cumulative Percentage of Total CO2 Emissions") +
theme(axis.text.x = element_text(angle = 90, hjust = 0.5),
legend.position = "none")
