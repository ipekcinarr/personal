library("tidyverse")
library("gridExtra")
library("xlsx")
library("ggplot2")
library("readxl")
country_a <- read_excel("C:/Users/LENOVO/Downloads/66casee.xlsx", sheet = "Country A")
country_b <- read_excel("C:/Users/LENOVO/Downloads/66casee.xlsx", sheet = "Country B")
#We start by subsetting the data for each country to only include data from the year 2019. We calculate the ratio of profit to total CO2 emissions for each company in that year and then identify the companies that meet the efficiency criterion (a ratio greater than 0.3).
data_2019a <- subset(country_a, Year == 2019)
data_2019a$Ratio <- data_2019a$`Profit (Million $)` / (data_2019a$`CO2_emission (petroleum)` + data_2019a$`CO2_emission (natural gas)` + data_2019a$`CO2_emission (coal)`)
efficient_companies_A<- subset(data_2019a, Ratio > 0.3)
proportion_efficient_A <- nrow(efficient_companies_A) / nrow(data_2019a)
data_2019b <- subset(country_b, Year == 2019)
data_2019b$Ratio <- data_2019b$`Profit (Million $)` / (data_2019b$`CO2_emission (petroleum)` + data_2019b$`CO2_emission (natural gas)` + data_2019b$`CO2_emission (coal)`)
efficient_companies_B<- subset(data_2019b, Ratio > 0.3)
proportion_efficient_B <- nrow(efficient_companies_B) / nrow(data_2019b)
# Check with normality test for data "Profit (Million $)"
# Calculate the mean and standard deviation of the data
xbar <- mean(efficient_companies_A$`Profit (Million $)`)
stdD <- sd(efficient_companies_A$`Profit (Million $)`)

# Create a histogram with a normal curve
hist(efficient_companies_A$`Profit (Million $)`, prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(efficient_companies_A$`Profit (Million $)`), max(efficient_companies_A$`Profit (Million $)`), length = 20)
f <- dnorm(x, xbar, sd = stdD)
lines(x, f, col = "red", lwd = 2)

# Create a Q-Q plot
par(mfrow = c(1,1)) # Set the layout of the plots
qqnorm(efficient_companies_A$`Profit (Million $)`); qqline(efficient_companies_A$`Profit (Million $)`)

#--------------
#Applying the process again fot the data in Country B
# Calculate the mean and standard deviation of the data
xbar <- mean(efficient_companies_B$`Profit (Million $)`)
stdD <- sd(efficient_companies_B$`Profit (Million $)`)

# Create a histogram with a normal curve
hist(efficient_companies_B$`Profit (Million $)`, prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(efficient_companies_B$`Profit (Million $)`), max(efficient_companies_B$`Profit (Million $)`), length = 20)
f <- dnorm(x, xbar, sd = stdD)
lines(x, f, col = "darkblue", lwd = 2)

# Create a Q-Q plot
par(mfrow = c(1,1)) # Set the layout of the plots
qqnorm(efficient_companies_B$`Profit (Million $)`); qqline(efficient_companies_B$`Profit (Million $)`)

#____________________________________________________________________
#Check with normality test for data "CO2_emission (petroleum)"
# Calculate the mean and standard deviation of the data
xbar <- mean(efficient_companies_A$`CO2_emission (petroleum)`)
stdD <- sd(efficient_companies_A$`CO2_emission (petroleum)`)

# Create a histogram with a normal curve
hist(efficient_companies_A$`CO2_emission (petroleum)`, prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(efficient_companies_A$`CO2_emission (petroleum)`), max(efficient_companies_A$`CO2_emission (petroleum)`), length = 20)
f <- dnorm(x, xbar, sd = stdD)
lines(x, f, col = "darkgreen", lwd = 2)

# Create a Q-Q plot
par(mfrow = c(1,1)) # Set the layout of the plots
qqnorm(efficient_companies_A$`CO2_emission (petroleum)`); qqline(efficient_companies_A$`CO2_emission (petroleum)`)

#----------
#Applying the process again fot the data in Country B
# Calculate the mean and standard deviation of the data
xbar <- mean(efficient_companies_B$`CO2_emission (petroleum)`)
stdD <- sd(efficient_companies_B$`CO2_emission (petroleum)`)

# Create a histogram with a normal curve
hist(efficient_companies_B$`CO2_emission (petroleum)`, prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(efficient_companies_B$`CO2_emission (petroleum)`), max(efficient_companies_B$`CO2_emission (petroleum)`), length = 20)
f <- dnorm(x, xbar, sd = stdD)
lines(x, f, col = "brown", lwd = 2)

# Create a Q-Q plot
par(mfrow = c(1,1)) # Set the layout of the plots
qqnorm(efficient_companies_B$`CO2_emission (petroleum)`); qqline(efficient_companies_B$`CO2_emission (petroleum)`)

#__________________________________________________________________________
# Check with normality test for data "CO2_emission (natural gas)"
# Calculate the mean and standard deviation of the data
xbar <- mean(efficient_companies_A$`CO2_emission (natural gas)`)
stdD <- sd(efficient_companies_A$`CO2_emission (natural gas)`)

# Create a histogram with a normal curve
hist(efficient_companies_A$`CO2_emission (natural gas)`, prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(efficient_companies_A$`CO2_emission (natural gas)`), max(efficient_companies_A$`CO2_emission (natural gas)`), length = 20)
f <- dnorm(x, xbar, sd = stdD)
lines(x, f, col = "gold", lwd = 2)

# Create a Q-Q plot
par(mfrow = c(1,1)) # Set the layout of the plots
qqnorm(efficient_companies_A$`CO2_emission (natural gas)`); qqline(efficient_companies_A$`CO2_emission (natural gas)`)

#---------------
#Applying the process again fot the data in Country B
# Calculate the mean and standard deviation of the data
xbar <- mean(efficient_companies_B$`CO2_emission (natural gas)`)
stdD <- sd(efficient_companies_B$`CO2_emission (natural gas)`)

# Create a histogram with a normal curve
hist(efficient_companies_B$`CO2_emission (natural gas)`, prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(efficient_companies_B$`CO2_emission (natural gas)`), max(efficient_companies_B$`CO2_emission (natural gas)`), length = 20)
f <- dnorm(x, xbar, sd = stdD)
lines(x, f, col = "orchid", lwd = 2)

# Create a Q-Q plot
par(mfrow = c(1,1)) # Set the layout of the plots
qqnorm(efficient_companies_B$`CO2_emission (natural gas)`); qqline(efficient_companies_B$`CO2_emission (natural gas)`)

#______________________________________________________________________________
# Check with normality test for data "CO2_emission (coal)"
# Calculate the mean and standard deviation of the data
xbar <- mean(efficient_companies_A$`CO2_emission (coal)`)
stdD <- sd(efficient_companies_A$`CO2_emission (coal)`)

# Create a histogram with a normal curve
hist(efficient_companies_A$`CO2_emission (coal)`, prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(efficient_companies_A$`CO2_emission (coal)`), max(efficient_companies_A$`CO2_emission (coal)`), length = 20)
f <- dnorm(x, xbar, sd = stdD)
lines(x, f, col = "orangered", lwd = 2)

# Create a Q-Q plot
par(mfrow = c(1,1)) # Set the layout of the plots
qqnorm(efficient_companies_A$`CO2_emission (coal)`); qqline(efficient_companies_A$`CO2_emission (coal)`)

#------------
#Applying the process again fot the data in Country B
# Calculate the mean and standard deviation of the data
xbar <- mean(efficient_companies_B$`CO2_emission (coal)`)
stdD <- sd(efficient_companies_B$`CO2_emission (coal)`)

# Create a histogram with a normal curve
hist(efficient_companies_B$`CO2_emission (coal)`, prob = TRUE, main = "Histogram with normal curve")
x <- seq(min(efficient_companies_B$`CO2_emission (coal)`), max(efficient_companies_B$`CO2_emission (coal)`), length = 20)
f <- dnorm(x, xbar, sd = stdD)
lines(x, f, col = "deeppink2", lwd = 2)

# Create a Q-Q plot
par(mfrow = c(1,1)) # Set the layout of the plots
qqnorm(efficient_companies_B$`CO2_emission (coal)`); qqline(efficient_companies_B$`CO2_emission (coal)`)
#We then calculate the proportions of efficient companies for each country, which will be used to calculate the sample difference in proportions later.
prop_A <- proportion_efficient_A
prop_B <- proportion_efficient_B
#We specify the sample sizes for each country.
n_A <- 20
n_B <- 16
sample_props <- c(prop_A, prop_B)
sample_sizes <- c(n_A, n_B)
#We calculate the pooled proportion, which is a weighted average of the two sample proportions based on the sample sizes.
pooled_prop <- sum(sample_props * sample_sizes) / sum(sample_sizes)
#We calculate the standard error of the difference in proportions using the pooled proportion and the sample sizes.
se_diff <- sqrt(pooled_prop * (1 - pooled_prop) * sum(1 / sample_sizes))
#Finally, we use the prop.test function in R to calculate a confidence interval for the difference in proportions at a 95% confidence level, without continuity correction (correct = FALSE). The function takes in the sample proportions and sizes, as well as the desired confidence level.
CI <- prop.test(sample_props * sample_sizes, sample_sizes, conf.level = 0.95, correct = FALSE, alternative = "two.sided")$conf.int
#___________________________________________________________________






