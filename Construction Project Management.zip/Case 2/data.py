import numpy as np

# PARAMETERS
# Create a 3 dimension np array as data for the parameter D (duration). Index 0 is for Project A and index 1 is for Project B.
D = [
    [
        [70, 42],
        [70, 42],
        [126, 77],
        [105, 63],
        [35, 21],
        [35, 21],
        [105, 63],
        [119, 70],
        [35, 21],
        [35, 21],
        [70, 42],
        [49, 28],
        [35, 21],
        [35, 21],
        [28, 21]
    ],
    [
        [139, 81],
        [78, 46],
        [292, 170],
        [34, 20],
        [90, 53],
        [18, 11],
        [48, 28],
        [24, 14],
        [72, 42],
        [19, 11],
        [36, 21],
        [17, 10],
        [96, 56],
        [96, 56]
    ]
]  # Duration of each activity in each project
P = [
    [None, 0, 1, 2, 0, 4, 5, 6, 7, 5, 9, 10, 10, 10, 8],
    [None, 0, 1, 2, 3, 4, 5, 6, 4, 7, 9, 10, 4, 11]
]  # Immediate predecessors of each activity in each project
S = [2200, 2500]  # Monthly salaries of each allocated contract worker in Project A and Project B respectively
W = 100  # Total number of contract workers available
E = [2150, 2500]  # Daily penalty for late completion of each project
L = [370, 420]  # Maximum number of days allowed for each project without penalty
U1 = [0.50, 0.55, 0.60, 0.65, 0.51, 0.24, 0.66, 0.75, 0.27, 0.30, 0.74, 0.40, 0.25, 0.22, 0.35]  # Crash rates of each activity in Project A
U2 = [0.11, 0.29, 0.60, 0.10, 0.42, 0.08, 0.29, 0.12, 0.43, 0.10, 0.20, 0.05, 0.33, 0.29]  # Crash rates of each activity in Project B


# SETS
I = np.arange(len(D[0]))  # Set of the activities in Project 1
M = np.arange(len(D[1]))  # Set of the activities in Project 2
C = np.arange(2)  # Set of number of duration conditions of activities. a = 0, b = 1
A = np.arange(2)  # Set of projects for worker proportional worker allocation between 0 and 1. A = 0, B = 1
