import numpy as np
import pandas as pd
import glpk
import pyomo.environ as pyo
from data import *

# Construct the model object as mdl
mdl = pyo.ConcreteModel('Case_2')

# Define the sets
mdl.I = pyo.Set(initialize=I, doc='Set of activities in Project A')
mdl.M = pyo.Set(initialize=M, doc='Set of activities in Project B')
mdl.C = pyo.Set(initialize=C, doc='Set of number of duration conditions of activities. a = 0, b = 1')
mdl.A = pyo.Set(initialize=A, doc='Set of projects. A and B')

# Define the parameters
mdl.pD = pyo.Param(mdl.I, initialize=lambda mdl, i: D[0][i], doc='Predefined durations of each activity in Project A', within=pyo.Any)
mdl.pP = pyo.Param(mdl.I, initialize=lambda mdl, i: P[0][i], doc='Immediate predecessors of each activity in Project A', within=pyo.Any)
mdl.pM = pyo.Param(mdl.M, initialize=lambda mdl, m: D[1][m], doc='Predefined durations of each activity in Project B', within=pyo.Any)
mdl.pQ = pyo.Param(mdl.M, initialize=lambda mdl, m: P[1][m], doc='Immediate predecessors of each activity in Project B', within=pyo.Any)
mdl.pS = pyo.Param(mdl.A, initialize=lambda mdl, a: S[a],
                   doc='Monthly salaries of each allocated contract worker in Project A and Project B respectively', within=pyo.Any)
mdl.pW = pyo.Param(initialize=W, doc='Total number of contract workers available', within=pyo.Any)

# mdl.pP.pprint()
# exit()

# Define the variables
mdl.vA = pyo.Var(mdl.A, bounds=(0.0, None), doc='Proportional worker allocation between 0 and 1. A = 0, B = 1',
                 within=pyo.NonNegativeReals)
mdl.vD1 = pyo.Var(mdl.I, bounds=(0.0, None), doc='Total duration (days) required to finish each activity in Project A',
                  within=pyo.NonNegativeReals)
mdl.vD2 = pyo.Var(mdl.M, bounds=(0.0, None), doc='Total duration (days) required to finish each activity in Project B',
                  within=pyo.NonNegativeReals)
mdl.vF1 = pyo.Var(mdl.I, bounds=(0.0, None), doc='Finish time of each activity in Project A',
                  within=pyo.NonNegativeReals)
mdl.vF2 = pyo.Var(mdl.M, bounds=(0.0, None), doc='Finish time of each activity in Project B',
                  within=pyo.NonNegativeReals)
mdl.vSMinus = pyo.Var(mdl.A, bounds=(0.0, None), doc='Under values of 2nd year of Project A and B',
                      within=pyo.NonNegativeReals)
mdl.vSPlus = pyo.Var(mdl.A, bounds=(0.0, None), doc='Excess values of 2nd year of Project A and B',
                     within=pyo.NonNegativeReals)


# Define the constraints
def eAllocated_Workers(mdl):
    return sum(mdl.vA[a] for a in mdl.A) == mdl.pW


mdl.eAllocated_Workers = pyo.Constraint(rule=eAllocated_Workers, doc='Total allocated workers must be equal to 100')


def eMax_Total_Duration_Goal_of_Both_Projects(mdl, p):
    return (mdl.vF1[len(mdl.I) - 1] if p == 0 else mdl.vF2[len(mdl.M) - 1]) + mdl.vSMinus[p] - mdl.vSPlus[p] == 360


mdl.eMax_Duration = pyo.Constraint(mdl.A, rule=eMax_Total_Duration_Goal_of_Both_Projects,
                                   doc='Total duration of Project A and B')


def eMax_Excess(mdl, p):
    return mdl.vSPlus[p] <= 360


mdl.eMax_Excess = pyo.Constraint(mdl.A, rule=eMax_Excess,
                                           doc='Under and excess values must be less than 360 days to meet the goal')


def eMax_Under(mdl, p):
    return mdl.vSMinus[p] <= 360


mdl.eMax_Under = pyo.Constraint(mdl.A, rule=eMax_Under,
                                           doc='Under and excess values must be less than 360 days to meet the goal')


def eDuration_of_Each_Activity_in_Project_A(mdl, i):
    return mdl.vD1[i] == mdl.pD[i][1] + ((mdl.vA[0] - mdl.pW) * (mdl.pD[i][0] - mdl.pD[i][1]) / (mdl.pW * -1))


mdl.eDuration_of_Each_Activity_in_Project_A = pyo.Constraint(mdl.I, rule=eDuration_of_Each_Activity_in_Project_A,
                                                             doc='Calculated duration of each activity according to the allocated C workers in Project A')


def eDuration_of_Each_Activity_in_Project_B(mdl, m):
    return mdl.vD2[m] == mdl.pM[m][1] + ((mdl.vA[1] - mdl.pW) * (mdl.pM[m][0] - mdl.pM[m][1]) / (mdl.pW * -1))


mdl.eDuration_of_Each_Activity_in_Project_B = pyo.Constraint(mdl.M, rule=eDuration_of_Each_Activity_in_Project_B,
                                                             doc='Calculated duration of each activity according to the allocated C workers in Project B')


def eFinish_Time_of_Each_Activity_in_Project_A(mdl, i):
    return mdl.vF1[i] >= (mdl.vF1[mdl.pP[i]] if mdl.pP[i] is not None else 0) + mdl.vD1[i]


mdl.eFinish_Time_of_Each_Activity_in_Project_A = pyo.Constraint(mdl.I, rule=eFinish_Time_of_Each_Activity_in_Project_A,
                                                                doc='Finish time of each activity in Project A must be greater than the sum of its duration and the finish time of its longest immediate predecessor')


def eFinish_Time_of_Each_Activity_in_Project_B(mdl, m):
    # mdl.vF1[m] must be greater than or equal to all the finish times of the immediate predecessors seperately of activity m and the duration of activity m
    return mdl.vF2[m] >= (mdl.vF2[mdl.pQ[m]] if mdl.pQ[m] is not None else 0) + mdl.vD2[m]


mdl.eFinish_Time_of_Each_Activity_in_Project_B = pyo.Constraint(mdl.M, rule=eFinish_Time_of_Each_Activity_in_Project_B,
                                                                doc='Finish time of each activity in Project B must be greater than the sum of its duration and the finish time of its longest immediate predecessor')


# Define the objective function
def oTotal_Cost(mdl):
    return 40 * ((mdl.pS[0] / 30 * (360 - mdl.vSMinus[0])) + (mdl.pS[0] * 1.15 * mdl.vSPlus[0] / 30)) + 60 * (
                (mdl.pS[1] / 30 * (360 - mdl.vSMinus[1])) + (mdl.pS[1] * 1.15 * mdl.vSPlus[1] / 30))


mdl.oTotal_Cost = pyo.Objective(rule=oTotal_Cost, sense=pyo.minimize, doc='Total cost of the project')


mdl.write('mdl.lp', io_options={'symbolic_solver_labels': True})
mdl.dual = pyo.Suffix(direction=pyo.Suffix.IMPORT)
mdl.rc = pyo.Suffix(direction=pyo.Suffix.IMPORT)

# Solve the model
solver = pyo.SolverFactory('glpk')
# solver.options['ranges'] = '/home/ce7in/code/python/pyomo/ranges.txt'
results = solver.solve(mdl, tee=True)
# results.write()

# mdl.pprint()
mdl.oTotal_Cost.display()
mdl.vA.display()
mdl.vSMinus.display()
mdl.vSPlus.display()
mdl.vD1.display()
mdl.vD2.display()
mdl.vF1.display()
mdl.vF2.display()
