import numpy as np
import pandas as pd
import glpk
import pyomo.environ as pyo
from data import *

# Construct the model object as mdl
mdl = pyo.ConcreteModel('Case_2')

# Define the sets
mdl.I = pyo.Set(initialize=I, doc='Set of activities in Project A')
mdl.M = pyo.Set(initialize=M, doc='Set of activities in Project B')
mdl.C = pyo.Set(initialize=C, doc='Set of number of duration conditions of activities. a = 0, b = 1')
mdl.A = pyo.Set(initialize=A, doc='Set of projects. A and B')

# Define the parameters
mdl.pD = pyo.Param(mdl.I, initialize=lambda mdl, i: D[0][i], doc='Predefined durations of each activity in Project A', within=pyo.Any)
mdl.pP = pyo.Param(mdl.I, initialize=lambda mdl, i: P[0][i], doc='Immediate predecessors of each activity in Project A', within=pyo.Any)
mdl.pM = pyo.Param(mdl.M, initialize=lambda mdl, m: D[1][m], doc='Predefined durations of each activity in Project B', within=pyo.Any)
mdl.pQ = pyo.Param(mdl.M, initialize=lambda mdl, m: P[1][m], doc='Immediate predecessors of each activity in Project B', within=pyo.Any)
mdl.pS = pyo.Param(mdl.A, initialize=lambda mdl, a: S[a],
                   doc='Monthly salaries of each allocated contract worker in Project A and Project B respectively', within=pyo.Any)
mdl.pW = pyo.Param(initialize=W, doc='Total number of contract workers available', within=pyo.Any)
mdl.pE = pyo.Param(mdl.A, initialize=lambda mdl, a: E[a], doc='Daily penalty for late completion of each project', within=pyo.Any)
mdl.pL = pyo.Param(mdl.A, initialize=lambda mdl, a: L[a], doc='Maximum number of days allowed for each project without penalty', within=pyo.Any)
mdl.pU1 = pyo.Param(mdl.I, initialize=lambda mdl, i: U1[i], doc='Crash rates of each activity in Project A', within=pyo.Any)
mdl.pU2 = pyo.Param(mdl.M, initialize=lambda mdl, m: U2[m], doc='Crash rates of each activity in Project B', within=pyo.Any)

# mdl.pP.pprint()
# exit()

# Define the variables
mdl.vA = pyo.Var(mdl.A, bounds=(0.0, None), doc='Proportional worker allocation between 0 and 1. A = 0, B = 1',
                 within=pyo.NonNegativeReals)
mdl.vD1 = pyo.Var(mdl.I, bounds=(0.0, None), doc='Total duration (days) required to finish each activity in Project A',
                  within=pyo.NonNegativeReals)
mdl.vD2 = pyo.Var(mdl.M, bounds=(0.0, None), doc='Total duration (days) required to finish each activity in Project B',
                  within=pyo.NonNegativeReals)
mdl.vF1 = pyo.Var(mdl.I, bounds=(0.0, None), doc='Finish time of each activity in Project A',
                  within=pyo.NonNegativeReals)
mdl.vF2 = pyo.Var(mdl.M, bounds=(0.0, None), doc='Finish time of each activity in Project B',
                  within=pyo.NonNegativeReals)
mdl.vSMinus = pyo.Var(mdl.A, bounds=(0.0, None), doc='Under values of 2nd year of Project A and B',
                      within=pyo.NonNegativeReals)
mdl.vSPlus = pyo.Var(mdl.A, bounds=(0.0, None), doc='Excess values of 2nd year of Project A and B',
                     within=pyo.NonNegativeReals)
mdl.vEMinus = pyo.Var(mdl.A, bounds=(0.0, None), doc='Under values of penalty of Project A and B', within=pyo.NonNegativeReals)
mdl.vEPlus = pyo.Var(mdl.A, bounds=(0.0, None), doc='Excess values of penalty of Project A and B', within=pyo.NonNegativeReals)
mdl.vU1 = pyo.Var(mdl.I, bounds=(0.0, None), doc='Budget for Project A WBSs', within=pyo.NonNegativeReals)
mdl.vU2 = pyo.Var(mdl.M, bounds=(0.0, None), doc='Budget for Project B WBSs', within=pyo.NonNegativeReals)


# Define the constraints
def eAllocated_Workers(mdl):
    return sum(mdl.vA[a] for a in mdl.A) == mdl.pW


mdl.eAllocated_Workers = pyo.Constraint(rule=eAllocated_Workers, doc='Max budget for Project A WBSs 1, 2, 3, 4')


def eMax_Budget_for_Project_A_WBS1234(mdl):
    return sum(mdl.vU1[i] for i in range(0, 3)) <= 40000 * 0.3


mdl.eMax_Budget_for_Project_A_WBS1234 = pyo.Constraint(rule=eMax_Budget_for_Project_A_WBS1234, doc='Max budget for Project A WBSs 1, 2, 3, 4')


def eMax_Budget_for_Project_A_WBS567891011(mdl):
    return sum(mdl.vU1[i] for i in range(4, 10)) <= 40000 * 0.5


mdl.eMax_Budget_for_Project_A_WBS567891011 = pyo.Constraint(rule=eMax_Budget_for_Project_A_WBS567891011, doc='Max budget for Project A WBSs 5, 6, 7, 8, 9, 10, 11')


def eMax_Budget_for_Project_B_WBS123(mdl):
    return sum(mdl.vU2[i] for i in range(0, 2)) <= 60000 * 0.4


mdl.eMax_Budget_for_Project_B_WBS123 = pyo.Constraint(rule=eMax_Budget_for_Project_B_WBS123, doc='Max budget for Project B WBSs 1, 2, 3')


def eMax_Budget_for_Project_A_WBS1314(mdl):
    return sum(mdl.vU2[i] for i in range(12, 13)) <= 60000 * 0.2


mdl.eMax_Budget_for_Project_A_WBS1314 = pyo.Constraint(rule=eMax_Budget_for_Project_A_WBS1314, doc='Max budget for Project A WBSs 12, 13')


def eMax_Budget_for_Project_A_All_WBSs(mdl):
    return sum(mdl.vU1[i] for i in mdl.I) <= 40000


mdl.eMax_Budget_for_Project_A_All_WBSs = pyo.Constraint(rule=eMax_Budget_for_Project_A_All_WBSs, doc='Max budget for Project A All WBSs')


def eMax_Budget_for_Project_B_All_WBSs(mdl):
    return sum(mdl.vU2[m] for m in mdl.M) <= 60000


mdl.eMax_Budget_for_Project_B_All_WBSs = pyo.Constraint(rule=eMax_Budget_for_Project_B_All_WBSs, doc='Max budget for Project B All WBSs')


def eMax_Finish_Time_of_All_Activities1(mdl, i):
    return mdl.vF1[i] <= mdl.vF1[len(mdl.I) - 1]


mdl.eMax_Finish_Time_of_All_Activities1 = pyo.Constraint(mdl.I, rule=eMax_Finish_Time_of_All_Activities1, doc='Finish time of each activity in Project A must be less than or equal to the finish time of the last activity in Project A')


def eMax_Finish_Time_of_All_Activities2(mdl, i):
    return mdl.vF2[i] <= mdl.vF2[len(mdl.M) - 1]


mdl.eMax_Finish_Time_of_All_Activities2 = pyo.Constraint(mdl.M, rule=eMax_Finish_Time_of_All_Activities2, doc='Finish time of each activity in Project A must be less than or equal to the finish time of the last activity in Project A')


def eMax_Total_Duration_Goal_of_Both_Projects(mdl, p):
    return (mdl.vF1[len(mdl.I) - 1] if p == 0 else mdl.vF2[len(mdl.M) - 1]) + mdl.vSMinus[p] - mdl.vSPlus[p] == 360


mdl.eMax_Duration = pyo.Constraint(mdl.A, rule=eMax_Total_Duration_Goal_of_Both_Projects,
                                   doc='Total duration of Project A and B')


def eDue_Date_Goal_of_Both_Projects(mdl, p):
    return (mdl.vF1[len(mdl.I) - 1] if p == 0 else mdl.vF2[len(mdl.M) - 1]) == mdl.pL[p] - mdl.vEMinus[p] + mdl.vEPlus[p]


mdl.eDue_Date_Derivation = pyo.Constraint(mdl.A, rule=eDue_Date_Goal_of_Both_Projects, doc='Due date derivation of Project A and B')


def eMax_Excess(mdl, p):
    return mdl.vSPlus[p] <= 360


mdl.eMax_Excess = pyo.Constraint(mdl.A, rule=eMax_Excess,
                                           doc='Under and excess values must be less than 360 days to meet the goal')


def eMax_Under(mdl, p):
    return mdl.vSMinus[p] <= 360


mdl.eMax_Under = pyo.Constraint(mdl.A, rule=eMax_Under,
                                           doc='Under and excess values must be less than 360 days to meet the goal')


def eDuration_of_Each_Activity_in_Project_A(mdl, i):
    return mdl.vD1[i] == mdl.pD[i][1] + ((mdl.vA[0] - mdl.pW) * (mdl.pD[i][0] - mdl.pD[i][1]) / (mdl.pW * -1))


mdl.eDuration_of_Each_Activity_in_Project_A = pyo.Constraint(mdl.I, rule=eDuration_of_Each_Activity_in_Project_A,
                                                             doc='Calculated duration of each activity according to the allocated C workers in Project A')


def eDuration_of_Each_Activity_in_Project_B(mdl, m):
    return mdl.vD2[m] == mdl.pM[m][1] + ((mdl.vA[1] - mdl.pW) * (mdl.pM[m][0] - mdl.pM[m][1]) / (mdl.pW * -1))


mdl.eDuration_of_Each_Activity_in_Project_B = pyo.Constraint(mdl.M, rule=eDuration_of_Each_Activity_in_Project_B,
                                                             doc='Calculated duration of each activity according to the allocated C workers in Project B')


def eFinish_Time_of_Each_Activity_in_Project_A(mdl, i):
    return mdl.vF1[i] >= (mdl.vF1[mdl.pP[i]] if mdl.pP[i] is not None else 0) + mdl.vD1[i] - ((sum(mdl.vU1[j] for j in mdl.I)) / 1000) * mdl.pU1[i]


mdl.eFinish_Time_of_Each_Activity_in_Project_A = pyo.Constraint(mdl.I, rule=eFinish_Time_of_Each_Activity_in_Project_A,
                                                                doc='Finish time of each activity in Project A must be greater than the sum of its duration and the finish time of its longest immediate predecessor')


def eFinish_Time_of_Each_Activity_in_Project_B(mdl, m):
    # mdl.vF1[m] must be greater than or equal to all the finish times of the immediate predecessors seperately of activity m and the duration of activity m
    return mdl.vF2[m] >= (mdl.vF2[mdl.pQ[m]] if mdl.pQ[m] is not None else 0) + mdl.vD2[m] - ((sum(mdl.vU2[j] for j in mdl.M)) / 1000) * mdl.pU2[m]


mdl.eFinish_Time_of_Each_Activity_in_Project_B = pyo.Constraint(mdl.M, rule=eFinish_Time_of_Each_Activity_in_Project_B,
                                                                doc='Finish time of each activity in Project B must be greater than the sum of its duration and the finish time of its longest immediate predecessor')


# Define the objective function
def oTotal_Cost(mdl):
    return 40 * ((mdl.pS[0] / 30 * (360 - mdl.vSMinus[0])) + (mdl.pS[0] * 1.15 * mdl.vSPlus[0] / 30)) + 60 * (
                (mdl.pS[1] / 30 * (360 - mdl.vSMinus[1])) + (mdl.pS[1] * 1.15 * mdl.vSPlus[1] / 30)) + (mdl.pE[0] * mdl.vEPlus[0]) + (mdl.pE[1] * mdl.vEPlus[1]) + sum(mdl.vU1[i] for i in mdl.I) + sum(mdl.vU2[i] for i in mdl.M)


mdl.oTotal_Cost = pyo.Objective(rule=oTotal_Cost, sense=pyo.minimize, doc='Total cost of the project')


mdl.write('mdl.lp', io_options={'symbolic_solver_labels': True})
mdl.dual = pyo.Suffix(direction=pyo.Suffix.IMPORT)
mdl.rc = pyo.Suffix(direction=pyo.Suffix.IMPORT)

# Solve the model
solver = pyo.SolverFactory('glpk')
solver.options['ranges'] = '/home/ce7in/code/python/pyomo/Ranges_Part_2_2.txt'
results = solver.solve(mdl, tee=True)
results.write()

# mdl.pprint()
mdl.oTotal_Cost.display()
mdl.vA.display()
mdl.vSMinus.display()
mdl.vSPlus.display()
mdl.vD1.display()
mdl.vD2.display()
mdl.vF1.display()
mdl.vF2.display()
mdl.vEMinus.display()
mdl.vEPlus.display()
mdl.vU1.display()
mdl.vU2.display()

